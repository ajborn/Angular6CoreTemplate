﻿namespace $safeprojectname$.Models {
	public class UserModel {
		public int ResourceID { get; set; }
		public int ResourceTypeID { get; set; }
		public int EmployeeID { get; set; }
		public int ContractorID { get; set; }
		public string EmployeeFullName { get; set; }
		public string SecurityFeatures { get; set; }
		public int EmployeeCountryID { get; set; }
		public string EmployeeCountry { get; set; }
	}
}