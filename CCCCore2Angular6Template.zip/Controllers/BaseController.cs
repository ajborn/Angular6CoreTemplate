﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using $safeprojectname$.Models;
using $safeprojectname$.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers {
	public class BaseController : Controller {
		
		private string _culture = "en";

		protected SqlConnection _conn = new SqlConnection();
		protected string _ConnectionString = "";//GetConnectionString();

		public void TestSession() {
			try {

				HttpContext.Session.SetInt32(SessionFields.ResourceID, 3477);
			}
			catch (Exception e) {
				Console.WriteLine(e);
				throw;
			}
		}

		public void CheckSession() {
			if (HttpContext.Session.Keys?.Count() == 0) {
				HttpContext.Session.SetInt32(SessionFields.Master_ResourceID, 0);
				HttpContext.Session.SetInt32(SessionFields.ResourceID, 0);
				HttpContext.Session.SetInt32(SessionFields.EmployeeID, 0);
				HttpContext.Session.SetInt32(SessionFields.ContractorID, 0);
				HttpContext.Session.SetString(SessionFields.EmployeeFullName, "");
				HttpContext.Session.SetString(SessionFields.SecurityFeatures, "");
				HttpContext.Session.SetInt32(SessionFields.EmployeeClassificationID, 0);
				HttpContext.Session.SetInt32(SessionFields.EmployeeCountryID, 0);
				HttpContext.Session.SetInt32(SessionFields.CurrentLanguageID, 0);
				HttpContext.Session.SetString(SessionFields.CurrentLanguageName, "English");
				HttpContext.Session.SetString(SessionFields.CurrentCulture, _culture);

				UserModel user = GetUserInformation(User.Identity.Name);
				if (user.ResourceID == 0) {
					//user = GetUserInformation(Properties.Settings.Default.TestEmployee);
				}
				HttpContext.Session.SetInt32(SessionFields.Master_ResourceID, user.ResourceID);
				HttpContext.Session.SetInt32(SessionFields.ResourceID, user.ResourceID);
				HttpContext.Session.SetInt32(SessionFields.Master_ResourceTypeID, user.ResourceTypeID);
				HttpContext.Session.SetInt32(SessionFields.ResourceTypeID, user.ResourceTypeID);
				HttpContext.Session.SetInt32(SessionFields.Master_EmployeeID, user.EmployeeID);
				HttpContext.Session.SetInt32(SessionFields.EmployeeID, user.EmployeeID);
				HttpContext.Session.SetInt32(SessionFields.ContractorID, user.ContractorID);
				HttpContext.Session.SetString(SessionFields.Master_EmployeeFullName, user.EmployeeFullName);
				HttpContext.Session.SetString(SessionFields.EmployeeFullName, user.EmployeeFullName);
				HttpContext.Session.SetString(SessionFields.Master_SecurityFeatures, user.SecurityFeatures);
				HttpContext.Session.SetString(SessionFields.SecurityFeatures, user.SecurityFeatures);
				HttpContext.Session.SetString(SessionFields.Master_EmployeeCountryID, user.EmployeeCountryID.ToString());
				HttpContext.Session.SetString(SessionFields.EmployeeCountryID, user.EmployeeCountryID.ToString());
			}
			ViewBag.ResourceID = HttpContext.Session.GetInt32(SessionFields.ResourceID);
			ViewBag.ResourceTypeID = HttpContext.Session.GetInt32(SessionFields.ResourceTypeID);
			ViewBag.EmployeeID = HttpContext.Session.GetInt32(SessionFields.EmployeeID);
			ViewBag.ContractorID = HttpContext.Session.GetInt32(SessionFields.ContractorID);
			ViewBag.EmployeeFullName = HttpContext.Session.GetString(SessionFields.EmployeeFullName);
			//ViewBag.SecurityFeatures = Session[SessionFields.SecurityFeatures]?.ToString();
			ViewBag.EmployeeCountryID = HttpContext.Session.GetInt32(SessionFields.EmployeeCountryID);
			ViewBag.User = User.Identity.Name;
		}

		public void CheckSession(int CountryID) {
			if (HttpContext.Session.Keys?.Count() == 0) {
				HttpContext.Session.SetInt32(SessionFields.Master_ResourceID, 0);
				HttpContext.Session.SetInt32(SessionFields.ResourceID, 0);
				HttpContext.Session.SetInt32(SessionFields.EmployeeID, 0);
				HttpContext.Session.SetString(SessionFields.EmployeeFullName, "");
				HttpContext.Session.SetInt32(SessionFields.EmployeeClassificationID, 0);
				HttpContext.Session.SetInt32(SessionFields.EmployeeCountryID, 0);

				UserModel user = GetUserInformation(User.Identity.Name.ToString());
				ViewBag.ResourceID = user.ResourceID;
				HttpContext.Session.SetInt32(SessionFields.Master_ResourceID, user.ResourceID);
				HttpContext.Session.SetInt32(SessionFields.ResourceID, user.ResourceID);
				ViewBag.ResourceTypeID = user.ResourceTypeID;
				HttpContext.Session.SetInt32(SessionFields.ResourceTypeID, user.ResourceTypeID);
				
				HttpContext.Session.SetInt32(SessionFields.EmployeeID, user.EmployeeID);
				HttpContext.Session.SetInt32(SessionFields.ContractorID, user.ContractorID);
				HttpContext.Session.SetInt32(SessionFields.EmployeeCountryID, user.EmployeeCountryID);
				HttpContext.Session.SetString(SessionFields.SecurityFeatures, user.SecurityFeatures);
				HttpContext.Session.SetString(SessionFields.EmployeeFullName, user.EmployeeFullName);

				ViewBag.EmployeeID = user.EmployeeID;
				ViewBag.ContractorID = user.ContractorID;
				ViewBag.SecurityFeatures = user.SecurityFeatures;
				ViewBag.EmployeeCountryID = user.EmployeeCountryID;
				ViewBag.EmployeeFullName = user.EmployeeFullName;

			}

			if (HttpContext.Session.GetInt32(SessionFields.Master_ResourceID) > 0) {
				SetPreferredCountry(HttpContext.Session.GetInt32(SessionFields.Master_ResourceID) ?? 0, CountryID);
			}

			//Set the Requested Country Code into the Session Variables.
			if (CountryID == 1) {
				HttpContext.Session.SetInt32(SessionFields.EmployeeCountryID, 1);
				HttpContext.Session.SetString(SessionFields.EmployeeCountry,"United States");
			} else if (CountryID == 2) {
				HttpContext.Session.SetInt32(SessionFields.EmployeeCountryID, 2);
				HttpContext.Session.SetString(SessionFields.EmployeeCountry, "Canada");
			}


			ViewBag.User = User.Identity.Name;

		}

		#region DataRetrieval

		public UserModel GetUserInformation(string LoginName) {
			var retval = new UserModel();
			// Set Defaults for retval.
			retval.ResourceID = 0;

			//Testing
			//if ((Properties.Settings.Default.TestingUser != "" && Properties.Settings.Default.TestingUser != "NULL")) //Properties.Settings.Default.ActiveDBConnection == "Testing" && 
			//{
			//	LoginName = Properties.Settings.Default.TestingUser;
			//}


			DataTable dtable = new DataTable();
			SqlDataAdapter da = new SqlDataAdapter();

			if (!ManageConnection(true)) {
				goto Clean_Up;
			}
			String sqlCommand = "Network_UserInformation";

			SqlCommand cmd = new SqlCommand(sqlCommand, _conn);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.CommandTimeout = 600;

			cmd.Parameters.Add(new SqlParameter("AppLogin", LoginName));

			try {
				da.SelectCommand = cmd;
				da.Fill(dtable);
			} catch {
				goto Clean_Up;
			}

			if (dtable.Rows.Count > 0) {
				//Get the ResourceID of the Current User.
				int tmpID = 0;
				int.TryParse(dtable.Rows[0][SessionFields.ResourceID].ToString(), out tmpID);
				retval.ResourceID = tmpID;
				tmpID = 0;
				int.TryParse(dtable.Rows[0][SessionFields.ResourceTypeID].ToString(), out tmpID);
				retval.ResourceTypeID = tmpID;
				retval.EmployeeFullName = dtable.Rows[0][SessionFields.Name].ToString();
				tmpID = 0;
				retval.SecurityFeatures = dtable.Rows[0][SessionFields.SecurityFeatures].ToString();
				int.TryParse(dtable.Rows[0][SessionFields.EmployeeID].ToString(), out tmpID);
				retval.EmployeeID = tmpID;
				tmpID = 0;
				int.TryParse(dtable.Rows[0][SessionFields.ContractorID].ToString(), out tmpID);
				retval.ContractorID = tmpID;
				tmpID = 0;
				int.TryParse(dtable.Rows[0][SessionFields.CountryID].ToString(), out tmpID);
				retval.EmployeeCountryID = tmpID;

			}

			Clean_Up:
			ManageConnection(false);
			da.Dispose();
			da = null;
			dtable.Dispose();
			dtable = null;
			cmd = null;
			return retval;
		}

		public Boolean SetPreferredCountry(Int32 ResourceID, Int32 CountryID) {
			DataTable dtable = new DataTable();
			SqlDataAdapter da = new SqlDataAdapter();
			Boolean retval = false;
			String sSQL = "";
			//String recID = "0";

			//Attempt to load record by ResourceID.
			sSQL = "Select * From AssignmentCountry Where ResourceID = " + ResourceID;

			if (!ManageConnection(true)) {
				goto Clean_Up;
			}

			SqlCommand cmd = new SqlCommand(sSQL, _conn);
			cmd.CommandType = CommandType.Text;
			cmd.CommandTimeout = 600;
			da.SelectCommand = cmd;

			try { da.Fill(dtable); } catch {
				goto Clean_Up;
			}

			if (dtable.Rows.Count > 0) {
				//If Record Exists updata Record with new CountryID.
				sSQL = "Update AssignmentCountry Set CountryID = " + CountryID + " Where AssignmentCountryID = " + dtable.Rows[0]["AssignmentCountryID"].ToString();
				cmd.CommandText = sSQL;
				try {
					Int32 r = cmd.ExecuteNonQuery();
					if (r > 0) {
						retval = true;
					}
				} catch { }

			} else {
				//If no record exists Insert new row.
				sSQL = "Insert into AssignmentCountry (ResourceID, CountryID) values (" + ResourceID + ", " + CountryID + ")";
				cmd.CommandText = sSQL;
				try {
					Int32 r = cmd.ExecuteNonQuery();
					if (r > 0) {
						retval = true;
					}
				} catch { }
			}


			Clean_Up:
			ManageConnection(false);
			da.Dispose();
			da = null;
			dtable.Dispose();
			dtable = null;
			cmd = null;

			//Return.
			return retval;
		}
		#endregion DataRetrieval

		public Boolean ManageConnection(Boolean toggle) {
			if (toggle) {
				try {
					if (_conn.State == ConnectionState.Open) {
						return true;
					} else {
						_conn.ConnectionString = _ConnectionString;
						_conn.Open();
						return true;
					}
				} catch {
					return false;
				}
			} else {
				try {
					_conn.Close();
					return true;
				} catch {
					return false;
				}
			}
		}

		//public static string GetConnectionString() {
		//	switch (Properties.Settings.Default.ActiveDBConnection) {
		//		case "Production":
		//			return Properties.Settings.Default.ProdConnection;
		//		case "Testing":
		//			return Properties.Settings.Default.TestConnection;
		//		case "Development":
		//			return Properties.Settings.Default.DevConnection;
		//		default:
		//			return Properties.Settings.Default.ProdConnection;
		//	}
		//}
	}
}

