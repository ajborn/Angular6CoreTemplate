﻿namespace $safeprojectname$.Services {
	
	public static class SessionFields {
		public const string UserName = nameof(UserName);
		public const string ContractorID = nameof(ContractorID);
		public const string ContractorName = nameof(ContractorName);
		public const string ContractorType = nameof(ContractorType);
		public const string CurrentCulture = nameof(CurrentCulture);
		public const string CurrentLanguageID = nameof(CurrentLanguageID);
		public const string CurrentLanguageName = nameof(CurrentLanguageName);
		public const string CountryID = nameof(CountryID);
		public const string CountryName = nameof(CountryName);
		public const string EmployeeClassificationID = nameof(EmployeeClassificationID);
		public const string EmployeeCountry = nameof(EmployeeCountry);
		public const string EmployeeCountryID = nameof(EmployeeCountryID);
		public const string EmployeeFullName = nameof(EmployeeFullName);
		public const string EmployeeID = nameof(EmployeeID);
		public const string IsContractor = nameof(IsContractor);
		public const string IsContractorEmployee = nameof(IsContractorEmployee);
		public const string IsPrismEmployee = nameof(IsPrismEmployee);
		public const string Master_EmployeeCountryID = nameof(Master_EmployeeCountryID);
		public const string Master_EmployeeFullName = nameof(Master_EmployeeFullName);
		public const string Master_EmployeeID = nameof(Master_EmployeeID);
		public const string Master_ResourceID = nameof(Master_ResourceID);
		public const string Master_ResourceTypeID = nameof(Master_ResourceTypeID);
		public const string Master_SecurityFeatures = nameof(Master_SecurityFeatures);
		public const string Name = nameof(Name);
		public const string PrismEmployeeClassificationID = nameof(PrismEmployeeClassificationID);
		public const string PrismEmployeeFullName = nameof(PrismEmployeeFullName);
		public const string ResourceID = nameof(ResourceID);
		public const string ResourceTypeID = nameof(ResourceTypeID);
		public const string ResourceTypeName = nameof(ResourceTypeName);
		public const string SecurityFeatures = nameof(SecurityFeatures);
		public const string SessionTimeout = nameof(SessionTimeout);
	}
}